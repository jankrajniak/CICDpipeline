import Question from './Question.js';

export default { Question };
